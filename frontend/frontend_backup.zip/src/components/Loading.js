
const Loading =()=>{
    return (
        <p id="loadingText">Loading...</p>
    );
}

export default Loading;